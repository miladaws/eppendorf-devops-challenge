import random
import json

def lambda_handler(event, context):
    status_codes = [200, 300, 400, 500, 501, 503, 507]
    selected_code = random.choice(status_codes)
    return {
        'statusCode': selected_code,
        'body': json.dumps({'status_code': selected_code})
    }